package com.example.alcmobile;

import android.app.Activity;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class Profile_activity extends AppCompatActivity{

//public variables

        ImageButton ImgbtnNavProfileBack ;
@Override
protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Get the view from activity_main xml
        setContentView(R.layout.activity_profile_activity);
        //Locate the button in activity_main.xml
        ImgbtnNavProfileBack = (ImageButton) findViewById(R.id.IBNavBackProfile);
        //Capture button clicks
    ImgbtnNavProfileBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Start NewActivity.class
                Intent myIntent = new Intent(Profile_activity.this,
MainActivity.class);
                startActivity(myIntent);
            }
        });



    }
}
