package com.example.alcmobile;

import android.widget.ImageButton;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class ProfileActivity extends Activity {

    ImageButton btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mprofileactiivity);
        //Locate the button in profileActivity.xml
        btnBack = (ImageButton) findViewById(R.id.btnProfileBack);

    //Capture button clicks
        btnBack.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                // start NewActivity class
                Intent myIntent = new Intent(ProfileActivity.this, MainActivity.class);
                startActivity(myIntent);
            }
        });

    }
}
