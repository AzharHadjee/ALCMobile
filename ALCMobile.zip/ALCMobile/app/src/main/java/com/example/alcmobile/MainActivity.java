package com.example.alcmobile;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class MainActivity  extends Activity
{
    //public variables
    Button button;
    Button btnProfileButton;
    ImageView imgLogo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Get the view from activity_main xml
        setContentView(R.layout.main_layout);

        //Locate the button in activity_main.xml
        button = (Button) findViewById(R.id.btnAbout);
        btnProfileButton = (Button) findViewById(R.id.btnNavProfile);
        //Locate the ImageView in activity_main.xml
        imgLogo = (ImageView) findViewById(R.id.imgVLogo);

        //Capture button clicks
        button.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                // Start NewActivity.class
                Intent myIntent = new Intent(MainActivity.this,
                        aboutActivity.class);
                startActivity(myIntent);
            }
        });

        btnProfileButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                // Start NewActivity.class
                Intent myProfileIntent = new Intent(MainActivity.this,
                        Profile_activity.class);
                startActivity(myProfileIntent);
            }
        });


    }
}
