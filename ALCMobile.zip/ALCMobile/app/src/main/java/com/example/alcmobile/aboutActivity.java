package com.example.alcmobile;


import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.SslErrorHandler;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ImageButton;

public class aboutActivity extends Activity {
    //public variables
//    Button btnBack;
//    private WebView webView;


    private WebView _wvAboutAlc;

    private WebView webView;
    private String _url = "https://andela.com";
    WebView mWebView;
    Button _btnNavBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        ImageButton btnBack;

        webView.getSettings().setJavaScriptEnabled(true);
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("https://andela.com/alc");
        // webView.loadUrl("https://www.ssaurel.com/blog");


        setContentView(R.layout.about_activity);



        //Locate the button in activity_main.xml
        btnBack = (ImageButton) findViewById(R.id.btnBack);

        mWebView = findViewById(R.id.myWebView);;
        setContentView(webView);
        mWebView.setWebViewClient(new WebViewClient() {


            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                view.loadUrl(url);
                return true;
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                handler.proceed(); // Ignore SSL certificate errors
            }
        });

//Capture button clicks
btnBack.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        //start new Activity class
        Intent __myIntent = new Intent(aboutActivity.this, MainActivity.class);
        startActivity(__myIntent);
    }
});
    }


}    //    }
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
////
////        _wvAboutAlc = new WebView(this);
////        setContentView(_wvAboutAlc);
////        _wvAboutAlc.loadUrl("https://andela.com/alc ");
////        _wvAboutAlc = R.layout.about_activity
//
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.about_activity);
//        _wvAboutAlc = (WebView) findViewById(R.id.myWebView);
//        _wvAboutAlc .setWebViewClient(new myWebClient());
//        _wvAboutAlc .getSettings().setJavaScriptEnabled(true);
//        //_wvAboutAlc.loadUrl("andela.com/");
//        _wvAboutAlc .loadUrl("https://andela.com/alc/");
//
//
//        //
//        }

//
//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        // Inflate the menu; this adds items to the action bar if it is present.
//        getMenuInflater().inflate(R.menu.menu_main, menu);
//        return true;
//    }
//
//    @Override
//    public boolean onOptionsItemSelected(MenuItem item) {
//        // Handle action bar item clicks here. The action bar will
//        // automatically handle clicks on the Home/Up button, so long
//        // as you specify a parent activity in AndroidManifest.xml.
//        int id = item.getItemId();
//
//        //noinspection SimplifiableIfStatement
//        if (id == R.id.action_settings) {
//            return true;
//        }
//
//        return super.onOptionsItemSelected(item);
//    }



// class myWebClient extends WebViewClient
//{
//    @Override
//    public void onPageStarted(WebView view, String url, Bitmap favicon) {
//// TODO Auto-generated method stub
//        super.onPageStarted(view, url, favicon);
//    }
//
//    @Override
//    public boolean shouldOverrideUrlLoading(WebView view, String url) {
//// TODO Auto-generated method stub
//
//        view.loadUrl(url);
//        return true;
//
//    }
//}

